// Mx Robohouse
// Coded by Marco Bibuli
// V1.0 - 23/03/2020


#ifndef __DEFINE__
#define __DEFINE__

#define CONFIGURATION_TOPICS_FILE "topics.cfg"
#define CONFIGURATION_IO_FILE "IO.cfg"
#define CONFIGURATION_PINGER_FILE "Pinger.cfg"
#define CONFIGURATION_FOG_FILE "FOG.cfg"
#define CONFIGURATION_GPS_AHRS_FILE "GPS_AHRS.cfg"
#define CONFIGURATION_USBL_FILE "USBL.cfg"
#define CONFIGURATION_DVL_FILE "DVL.cfg"
#define CONFIGURATION_CTD_FILE "CTD.cfg"
#define CONFIGURATION_PA500_FILE "PA500.cfg"
#define CONFIGURATION_ECHOLOGGER_FILE "Echologger.cfg"
#define CONFIGURATION_UBLOX_FILE "Ublox.cfg"

#define CONFIGURATION_GROUND_GPS_AHRS_FILE "Ground_GPS_AHRS.cfg"

#define ANG_FILTER_PARAMS_FILE "AngFilter.cfg"
#define HORVEL_FILTER_PARAMS_FILE "HorVelFilter.cfg"
#define HORPOS_FILTER_PARAMS_FILE "HorPosFilter.cfg"
#define VERVEL_FILTER_PARAMS_FILE "VerVelFilter.cfg"
#define VERPOS_FILTER_PARAMS_FILE "VerPosFilter.cfg"
#define ALT_FILTER_PARAMS_FILE "AltFilter.cfg"


#define ANGVEL_CONTROL_PARAMS_FILE "AngVelControl.cfg"
#define ANGPOS_CONTROL_PARAMS_FILE "AngPosControl.cfg"
#define HORVEL_CONTROL_PARAMS_FILE "HorVelControl.cfg"
#define HORPOS_CONTROL_PARAMS_FILE "HorPosControl.cfg"
#define VERVEL_CONTROL_PARAMS_FILE "VerVelControl.cfg"
#define VERPOS_CONTROL_PARAMS_FILE "VerPosControl.cfg"
#define ALT_CONTROL_PARAMS_FILE "AltControl.cfg"
#define PATH_FOLLOWING_UA_PARAMS_FILE "PathFollowing_UA.cfg"
#define PATH_FOLLOWING_FA_PARAMS_FILE "PathFollowing_FA.cfg"


#define gps_ahrs_serial_name "/dev/ttyS0"
#define ctd_serial_name "/dev/ttyS1"
#define dvl_serial_name "/dev/ttyS6"
#define pa500_serial_name "/dev/ttyS4"
#define pinger_serial_name "/dev/ttyS3"
#define echologger_serial_name "/dev/ttyUSB1"
#define ublox_serial_name "/dev/ttyUSB0"

#define ground_gps_ahrs_serial_name "/dev/ttyUSB0"

#define MEASURE_RAW 0
#define MEASURE_FILTER 1

#define SENSOR_FOG 0
#define SENSOR_GPS_AHRS 1
#define SENSOR_DVL 2
#define SENSOR_CTD 3
#define SENSOR_PA500 4
#define SENSOR_ECHOLOGGER 5
#define SENSOR_USBL 6
#define SENSOR_UBLOX 7

#define BUF_SIZE 1024
#define nameLength 256

#define CORE_SAMPLE_TIME_SEC 		0
#define CORE_SAMPLE_TIME_NSEC 		100000000

#define TELEMETRY_TIME_SEC 			0
#define TELEMETRY_TIME_NSEC 		100000000


#define COMM_LINK_SLEEP_SEC 		0
#define COMM_LINK_SLEEP_NSEC 		50000000

#define IO_SLEEP_SEC 				0
#define IO_SLEEP_NSEC 				100000000
#define IO_START_TICKS				10
#define IO_STOP_TICKS				1

#define MOTORS_SLEEP_SEC 			0
#define MOTORS_SLEEP_NSEC 			100000000

#define GPS_SLEEP_SEC 				0
#define GPS_SLEEP_NSEC 				100000000

#define COMPASS_SLEEP_SEC 			0
#define COMPASS_SLEEP_NSEC 			100000000

#define FOG_SLEEP_SEC 				0
#define FOG_SLEEP_NSEC 				100000000

#define DVL_SLEEP_SEC 				0
#define DVL_SLEEP_NSEC 				100000000

#define CTD_SLEEP_SEC 				0
#define CTD_SLEEP_NSEC 				100000000

#define GPS_AHRS_SLEEP_SEC 			0
#define GPS_AHRS_SLEEP_NSEC 		100000000

#define PA500_SLEEP_SEC 			0
#define PA500_SLEEP_NSEC 			100000000

#define ECHOLOGGER_SLEEP_SEC 		0
#define ECHOLOGGER_SLEEP_NSEC 		100000000

#define PINGER_SLEEP_SEC 			0
#define PINGER_SLEEP_NSEC 			200000000

#define USBL_POS_SLEEP_SEC 			0
#define USBL_POS_SLEEP_NSEC 		100000000

#define USBL_SLEEP_SEC 				0
#define USBL_SLEEP_NSEC 			100000000

#define UBLOX_SLEEP_SEC 			0
#define UBLOX_SLEEP_NSEC 			100000000

#define GROUND_GPS_AHRS_SLEEP_SEC 	0
#define GROUND_GPS_AHRS_SLEEP_NSEC 	100000000

#define ACTUATOR_SLEEP_SEC 			0
#define ACTUATOR_SLEEP_NSEC 		100000000

#define NGC_SLEEP_SEC 				0
#define NGC_SLEEP_NSEC 				100000000

#define TASK_SLEEP_SEC 				0
#define TASK_SLEEP_NSEC 			100000000

#define COMM_LINK_WAITING_LOOPS 	50  // loops for re-transmission in case of no-ack
#define COMM_LINK_LOST_LOOPS 		3    // loops for LOST state triggering

#define FOG_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define FOG_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define GPS_AHRS_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define GPS_AHRS_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define CTD_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define CTD_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define DVL_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define DVL_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define PA500_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define PA500_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define ECHOLOGGER_RECEIVE_WAIT_LOOPS_FOR_WARNING  50
#define ECHOLOGGER_RECEIVE_WAIT_LOOPS_FOR_FAULT    100

#define UBLOX_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define UBLOX_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define PINGER_RECEIVE_WAIT_LOOPS_FOR_WARNING  10
#define PINGER_RECEIVE_WAIT_LOOPS_FOR_FAULT    50

#define USBL_RECEIVE_WAIT_LOOPS_FOR_WARNING  50
#define USBL_RECEIVE_WAIT_LOOPS_FOR_FAULT    100

#define CLOCK_THREAD_PRIORITY		80
#define PINGER_THREAD_PRIORITY		80
#define USBL_THREAD_PRIORITY		80
#define COMM_LINK_THREAD_PRIORITY	80
#define SIMULATOR_THREAD_PRIORITY 	70
#define TELEMETRY_THREAD_PRIORITY 	70
#define COMMANDS_THREAD_PRIORITY 	70
#define IO_THREAD_PRIORITY			70
#define MOTORS_THREAD_PRIORITY 		70
#define GPS_AHRS_THREAD_PRIORITY 	70
#define GROUND_GPS_AHRS_THREAD_PRIORITY 	70
#define DVL_THREAD_PRIORITY 		70
#define CTD_THREAD_PRIORITY 		70
#define PA500_THREAD_PRIORITY 		70
#define ECHOLOGGER_THREAD_PRIORITY 	70
#define UBLOX_THREAD_PRIORITY 	70
#define USBL_POS_THREAD_PRIORITY	70
#define FOG_THREAD_PRIORITY 		70
#define ACTUATOR_THREAD_PRIORITY 	70
#define NGC_THREAD_PRIORITY 		60
#define TASKS_THREAD_PRIORITY 		60
#define PATHPLANNER_THREAD_PRIORITY 50
#define LOGGER_THREAD_PRIORITY		80


#define MAX_MQTT_LOOP_WAIT 100




#ifdef __MAIN__
   #define PRE
#else
   #define PRE extern
#endif // __MAIN__

PRE char _debugString[256];

PRE char ROBOT_NAME[256];
PRE char CONFIGURATION_FILES_DIRECTORY[256];
PRE char CONFIGURATION_SIM_FILES_DIRECTORY[256];



#endif
