import threading
import uuid
import multiprocessing

from transformations import script_convert, byte_convert

class Channel(multiprocessing.Process):
    def __init__(self, conf):
        super().__init__()
        self.gconf = conf
        self.conf = conf.get('connections')[0]
        self.outgoing = {}

    def setup_incoming(self):
        print('inbound connections')
        import inbound
        in_conf = self.conf.get('incoming')
        print(in_conf)
        if in_conf.get('protocol') == "serial":
            self.incoming = inbound.serial.Connector(in_conf, self.conf.get('name'))
        elif in_conf.get('protocol') in ["tcp", "udp"]:
            self.incoming = inbound.socket.Connector(in_conf, self.conf.get('name'))
        elif in_conf.get('protocol') == "mqtt":
            self.incoming = inbound.mqtt.Connector(in_conf, self.conf.get('name'))
        self.incoming.data_received = self.on_message
        self.incoming.run()

    def on_message(self, message, qos):
        print(message, qos)
        out = self.transformation(message)
        self.broadcast(out)

    def transformation(self, message):
        return message

    def broadcast(self, message):
        for o in self.outgoing.keys():
            self.outgoing[o].send_msg(message)

    def setup_outgoing(self):
        print('outbound connections')
        import outbound
        for out_conf in  self.conf.get('outgoing'):                
            if out_conf.get('enabled', True):
                print(out_conf)
                if out_conf.get('protocol') == "serial":
                    out = outbound.serial.Connector(out_conf, self.conf.get('name'))
                    out.run()
                    self.outgoing[out_conf.get('name', str(uuid.uuid4()))] = out
                elif out_conf.get('protocol') in ["tcp", "udp"]:
                    out = outbound.socket.Connector(out_conf, self.conf.get('name'))
                    out.run()
                    self.outgoing[out_conf.get('name', str(uuid.uuid4()))] = out
                elif out_conf.get('protocol') == "mqtt":
                    out = outbound.mqtt.Connector(out_conf, self.conf.get('name'))
                    out.run()
                    self.outgoing[out_conf.get('name', str(uuid.uuid4()))] = out



    def setup_transformation(self):
        print('transformations')
        self.trans_conf = self.conf.get('transformation')
        print(self.trans_conf)

    def transform(self, message):
        if self.trans_conf.get('mode', 'noop') == "format": 
            fmt = self.trans_conf.get('format')
            fmt = json.load(open(f'formats/{fmt}.json'))

        elif self.trans_conf.get('mode', 'noop') == "script":
            params = []

            self.transformation = script_convert
            data_out = script_convert(params, self.trans_conf.get('script'))




    def startup(self):
        self.setup_outgoing()
        self.setup_transformation()
        self.setup_incoming()

    def run(self):
        self.startup()
        

if __name__ == "__main__":
    import json
    j = json.load(open('config.json'))
    c = Channel(j)
    c.start()

